sh ./get_z.sh
sh ./get_data.sh
sh ./run_sqlldr.sh
