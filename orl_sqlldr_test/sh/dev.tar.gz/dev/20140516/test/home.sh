home=`pwd`
echo $home
